from django.urls import path
from nwankwochibikescrumy import views


urlpatterns = [
    path('', views.index)
]

