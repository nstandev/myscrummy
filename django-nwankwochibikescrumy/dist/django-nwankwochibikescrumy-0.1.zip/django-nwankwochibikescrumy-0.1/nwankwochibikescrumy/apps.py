from django.apps import AppConfig


class NwankwochibikescrumyConfig(AppConfig):
    name = 'nwankwochibikescrumy'
